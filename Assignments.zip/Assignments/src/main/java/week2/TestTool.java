package week2;

public interface TestTool {
	
	public void Selenium();

}
