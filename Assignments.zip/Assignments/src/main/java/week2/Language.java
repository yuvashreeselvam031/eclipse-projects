package week2;

public interface Language {

	public void java();
	

}
