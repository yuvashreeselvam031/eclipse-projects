package week2;

public abstract class MultipleLangauge {

public void python() {
	System.out.println("python");
}
public abstract void ruby();


}
