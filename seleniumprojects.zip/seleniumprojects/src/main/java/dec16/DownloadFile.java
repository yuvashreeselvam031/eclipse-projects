package dec16;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DownloadFile {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/download.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		WebElement findElement = driver.findElement(By.linkText("Download Excel"));
		findElement.click();
		Thread.sleep(3000);
		
		
		File fileLocation = new File("C:\\Users\\Admin\\Downloads");
		File[] listFiles = fileLocation.listFiles();
		for (File file : listFiles) {
			if (file.getName().contains("testleaf.xlsx")) {
				System.out.println(file.getName()+" file is downloaded");
				break;
			}
			
		}
		/*
		 * driver.findElement(By.linkText("Download PDF")).click(); Set<String>
		 * windowHandles = driver.getWindowHandles(); List<String> winList = new
		 * ArrayList<String>(windowHandles); driver.switchTo().window(winList.get(1));
		 */
		

		
	}

}
