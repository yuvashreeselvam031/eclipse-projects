package assignment2;

public class College {

	public void collegeName() {

		System.out.println("collegeName: RBGJainCollege");
	}
	public void collegeCode() {

		System.out.println("collegeCode : 7623847");
	}
	public void collegeRank() {

		System.out.println("collegeRank: 5th");
		
	}
		
}
