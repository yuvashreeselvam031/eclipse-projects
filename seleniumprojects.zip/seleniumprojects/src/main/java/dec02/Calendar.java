package dec02;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Calendar {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/Calendar.html");
		driver.findElement(By.className("hasDatepicker")).click();
		driver.findElement(By.xpath("(//a[@class='ui-state-default'])[9]")).click();
		

		//driver.findElement(By.className("hasDatepicker")).click();
	//	driver.findElement(By.linkText("12")).click();
		
		driver.findElement(By.className("hasDatepicker")).click();
		driver.findElement(By.xpath("(//table[@class='ui-datepicker-calendar']//tr/td[6])/a")).click();
		
		
	}

}
