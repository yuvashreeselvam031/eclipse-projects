package dec02;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class VerificationAndValidation {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/Edit.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		String currentUrl = driver.getCurrentUrl();
		System.out.println("currentUrl "+currentUrl);
		String title = driver.getTitle();
		System.out.println("title "+title);
		String pageSource = driver.getPageSource();
		System.out.println("pageSource "+pageSource);
		
		String att = driver.findElement(By.xpath("//label[text()='Append a text and press keyboard tab']/following-sibling::input")).getAttribute("value");		
		System.out.println(att);
		
		String tagName = driver.findElement(By.xpath("//label[text()='Get default text entered']")).getTagName();
		System.out.println("tagName "+tagName);
		
		String cssValue = driver.findElement(By.xpath("//div[@class='large-6 small-12 columns']")).getCssValue("color");
		System.out.println("cssValue "+cssValue);
		
		String text = driver.findElement(By.xpath("//div[@class='large-6 small-12 columns']")).getText();
		System.out.println("text");
		
		Point location = driver.findElement(By.xpath("//div[@class='large-6 small-12 columns']")).getLocation();
		System.out.println("location "+location);
		
		int x = driver.findElement(By.xpath("//div[@class='large-6 small-12 columns']")).getLocation().getX();
		System.out.println("x "+x);
		
		Dimension size = driver.findElement(By.xpath("//div[@class='large-6 small-12 columns']")).getSize();
		System.out.println("size "+size);
		
		int width = driver.findElement(By.xpath("//div[@class='large-6 small-12 columns']")).getSize().getWidth();
		System.out.println("width "+width); 
		
			
	}

}
