package dec02;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Draggable {

	public static void main(String[] args) throws InterruptedException {


		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/drag.html");
		WebElement dragme = driver.findElement(By.xpath("//p[text()='Drag me around']"));

		Point location = driver.findElement(By.xpath("//p[text()='Drag me around']")).getLocation();
		System.out.println(location);
		Actions builder = new Actions(driver);
		builder.dragAndDropBy(dragme, 450, 300).perform();
	}

}
