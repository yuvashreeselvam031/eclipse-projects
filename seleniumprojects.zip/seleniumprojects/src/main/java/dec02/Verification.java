package dec02;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Verification {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/radio.html");

		boolean displayed = driver.findElement(By.xpath("//input[@class='myradio']")).isDisplayed();
		System.out.println("displayed "+displayed);
		 
		boolean enabled = driver.findElement(By.xpath("//input[@class='myradio']")).isEnabled();
		System.out.println("enabled "+enabled);
		
		boolean selected = driver.findElement(By.xpath("//input[@class='myradio']")).isSelected();
		System.out.println("selected "+selected);
		
	
	}

}
