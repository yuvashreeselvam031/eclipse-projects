package nov18;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckBox {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/checkbox.html");
		driver.findElement(
				By.xpath("//label[text()='Select the languages that you know?']/following-sibling::div/input")).click();
		boolean selected = driver
				.findElement(By.xpath("//label[text()='Confirm Selenium is checked']/following-sibling::div/input"))
				.isSelected();
		if (selected==true) {
			System.out.println("It is checked");

		} else {

			System.out.println("It is not checked");
		}
		
	}
}
