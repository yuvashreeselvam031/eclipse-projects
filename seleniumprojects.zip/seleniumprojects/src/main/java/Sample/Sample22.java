package Sample;

public class Sample22 {

	public static void main(String[] args) {

		int[] a = {1,2,3,4,5,6};
		int length = a.length;
		System.out.println("array.length " +length);
		String s = "123456";
		int length2 = s.length();
		String concat = s.concat("9");
		System.out.println(s);
		System.out.println(concat);
		System.out.println("string.length() "+length2);
	}

}
