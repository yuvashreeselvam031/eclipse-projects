package nov30;

public class LearnStatic {
	
	
	


	public static void method1() {

		System.out.println("static method");
	}
	
	public void sum() {
		// TODO Auto-generated method stub
System.out.println("Super");
	}
	
	public static void main(String[] args) {
		LearnStatic ls = new LearnStatic();
		ls.method1();
	}
	
	
}
