package nov30;

public class ExecutionClass extends LearnStatic {

	
		
		

	public final void method1(int a, int b) {

		System.out.println(a+b);
	}
	
	public final void method1(int a, int b, int c) {

		System.out.println(a+b+c);
	}
	
	
	public static void main(String[] args) {

		//LearnStatic c = new ExecutionClass();
		ExecutionClass c1= new ExecutionClass();
		c1.method1(10,6);
		c1.method1(10,6,5);
		method1();
		LearnStatic.main(args);

		LearnStatic.method1();
		//LearnStatic.method1();
		//c1.method1();
	}
	public void sum() {
		// TODO Auto-generated method stub
System.out.println("Normal");
	}

	public static void method1() {

		System.out.println("----");
	}
}