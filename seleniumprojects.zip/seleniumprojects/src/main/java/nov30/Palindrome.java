package nov30;

public class Palindrome {

	public static void main(String[] args) {


		String a = "miadajm";
		
		int length = a.length();
		boolean flag = true;
	for (int i = 0; i < length; i++) {
		
		char ch = a.charAt(i);
		char ch2 = a.charAt(length-1);
		
		if (ch==ch2) {
			flag= true ;
			
		} else {

			flag = false;
		//	break;
		}
		length--;
	}
	if (flag==true) {
		System.out.println("it is a palindrome");
		
	}else
	{
		System.out.println("it is not a palindrome");
	}
	}

}
