package nov30;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnFrame {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/frame.html");
	    List<WebElement> frames = driver.findElements(By.tagName("iframe"));
		//driver.switchTo().frame(frames);
	   // int count = 0;
	    int size = frames.size();//3
	   
		for (int i = 0; i < frames.size() ; i++) {//0,1,2
			driver.switchTo().frame(frames.get(i));//0,1,2
	List<WebElement> innerFrame = driver.findElements(By.tagName("iframe"));//0,1,1
			size = size + innerFrame.size();//3+0=3+1=4+1=5
			driver.switchTo().defaultContent();
			
		}
		System.out.println(size);
	}

}
