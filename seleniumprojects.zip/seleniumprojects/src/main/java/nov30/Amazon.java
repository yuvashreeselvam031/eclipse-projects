package nov30;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Amazon {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		WebDriver driver1 = new ChromeDriver();
		driver1.findElement(By.id("username"));
		
	
		List<WebElement> findElements = driver.findElements(By.tagName("a"));
		
		System.out.println(findElements.size());

List<WebElement> img = driver.findElements(By.tagName("img"));
		
		System.out.println(img .size());

	}

}
