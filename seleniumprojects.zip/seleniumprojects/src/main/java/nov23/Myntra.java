package nov23;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Myntra {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.myntra.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		// 2) Mouse hover on MeN
		Actions builder = new Actions(driver);
		WebElement men = driver.findElement(By.linkText("MEN"));
		builder.moveToElement(men).perform();
		// 3) Click Jackets

		Thread.sleep(3000);
		driver.findElement(By.linkText("Jackets")).click();
        //	4) Find the total count of item 
		String text = driver.findElement(By.xpath("//span[@class='title-count']")).getText();
		System.out.println(text);
		//	6) Check jackets
		driver.findElement(By.xpath("//div[@class='common-checkboxIndicator']")).click();
		//	7) Click + More option under BRAND
		driver.findElement(By.xpath("//div[@class='brand-more']")).click();
		//	8) Type Duke and click checkbox
		driver.findElement(By.xpath("//input[@class='FilterDirectory-searchInput']")).sendKeys("Duke");
		driver.findElement(By.xpath("//span[@class='FilterDirectory-count']/following-sibling::div")).click();		//	9) Close the pop-up x
		Thread.sleep(3000);
		//driver.navigate().back();
		driver.findElement(By.xpath("//span[@class='myntraweb-sprite FilterDirectory-close sprites-remove']")).click();
		//	10) Confirm all the Coats are of brand Duke
		List<WebElement> dukelist = driver.findElements(By.xpath("//h3[text()='Duke']"));
		
				for (int i = 0; i <=dukelist.size(); i++) {
					String string = dukelist.get(i).toString();
			if (!string.contains("Duke")) {
				System.out.println("this "+dukelist.get(i).toString()+ " is not duke brand");
			}
		}
				WebElement sort = driver.findElement(By.className("sort-sortBy"));
				builder.moveToElement(sort).perform();
				driver.findElement(By.xpath("//input[@value='discount']/parent::label")).click();

				WebElement firstPrdt = driver.findElement(By.xpath("//span[@class='product-discountedPrice']"));

				String text2 = driver.findElement(By.xpath("//span[@class='product-discountedPrice']")).getText();				
				
				System.out.println("text2");
				WebElement price = driver.findElement(By.xpath("//span[@class='product-discountedPrice']"));
				 
				builder.moveToElement(price).perform();
				driver.findElement(By.xpath("//div[@class='product-actions ']/span")).click();
				

		





	}

}
