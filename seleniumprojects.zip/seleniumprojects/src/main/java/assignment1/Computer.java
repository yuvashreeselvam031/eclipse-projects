package assignment1;

public class Computer {

	public void computerModel() {

		System.out.println("computer model: lenova");
	}

}
