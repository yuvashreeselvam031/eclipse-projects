package dec14;

public interface Interfaces {

	public void Interfaces();
	
}
