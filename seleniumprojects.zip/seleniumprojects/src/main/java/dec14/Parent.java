package dec14;

public class Parent {

	public void move() {
	      System.out.println("Animals can move");
	   }
}
