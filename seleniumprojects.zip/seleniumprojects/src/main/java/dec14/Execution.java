package dec14;

public class Execution implements Interfaces {

	

	public void Interfaces() {

		System.out.println("Interfaces");
	}

}
