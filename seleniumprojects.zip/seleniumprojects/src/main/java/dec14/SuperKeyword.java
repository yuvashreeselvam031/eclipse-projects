package dec14;

public class SuperKeyword   {

	public static void main(String[] args) {

		 
		      Parent b = new Child(); // Animal reference but Dog object
		      b.move(); // runs the method in Dog class
		   
	}

}
