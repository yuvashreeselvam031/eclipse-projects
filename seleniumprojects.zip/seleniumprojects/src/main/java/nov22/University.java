package nov22;

public abstract class University {
	public void pg() {
 System.out.println("pg");
	}
	public abstract void ug();

}
