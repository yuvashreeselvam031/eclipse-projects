package nov22;

public class Class2 extends Abstraction{

	public static void main(String[] args) {

		Class2 c  = new Class2();
		c.method1();
		
	}

	@Override
	public void method2() {
		System.out.println("method2");

		
	}

}
