package nov22;

abstract class Abstraction {

	public void method1() {

System.out.println("method1");
	}
	public abstract void method2(); 
		
	

}
