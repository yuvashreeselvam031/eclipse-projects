package nov22;

public class Class3 extends Abstraction{

	public static void main(String[] args) {

		Class3 c2 = new Class3();
		c2.method1();
		c2.method2();
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		
	}

}
