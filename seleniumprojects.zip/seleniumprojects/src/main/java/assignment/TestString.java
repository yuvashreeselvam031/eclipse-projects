package assignment;

public class TestString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = new String("Saheel");
		System.out.println(name);
		int length = name.length();
		System.out.println(length);
		 name = name.concat("Test");
		 int length2 = name.length()-1;
		 System.out.println(name);
		 System.out.println(length2);
		  name = name.replace("ee", "oo");
System.out.println(name);

 
	}

}

