package dec08;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DeleteLead {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		System.out.println(System.getProperty("webdriver.chrome.driver"));
		
		//Launch the chromebrowser
		ChromeDriver driver = new ChromeDriver();
		
		//1. Launch URL "http://leaftaps.com/opentaps/control/login"
		driver.get("http://leaftaps.com/opentaps/control/login");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		//* 2. Enter UserName and Password Using Id Locator
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		// * 3. Click on Login Button using Class Locator
		driver.findElement(By.className("decorativeSubmit")).click();
		
		//* 4. Click on CRM/SFA Link
		driver.findElement(By.linkText("CRM/SFA")).click();
		
		//6	Click Leads link
		driver.findElement(By.linkText("Leads")).click();
		
		//7	Click Find leads
		driver.findElement(By.linkText("Find Leads")).click();
		
		//8. Click on Phone
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		
		//9.Enter phone number
		//driver.findElement(By.name("phoneAreaCode")).sendKeys("2");
		driver.findElement(By.name("phoneNumber")).sendKeys("98");
		
		//10.Click find leads button
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(5000);

		//11.Capture lead ID of First Resulting lead
		//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a
		////div[@class=�x-grid3-cell-inner x-grid3-col-partyId�]/a
		String ele4= driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		System.out.println(ele4);
		//12.Click First Resulting lead
		driver.findElement(By.xpath( "//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		//Thread.sleep(5000);
		//13.click Delete
		driver.findElement(By.linkText("Delete")).click();
		
		//14.Click find leads
		driver.findElement(By.linkText("Find Leads")).click();
		
		//15. enter the captured lead
		driver.findElement(By.name("id")).sendKeys(ele4);
		
		//16.Click find leads
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		
		
		
		//.
		
		
		
		
		
		
		
		
		
		
}
}