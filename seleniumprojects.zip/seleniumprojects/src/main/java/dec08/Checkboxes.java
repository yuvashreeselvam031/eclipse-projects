package dec08;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Checkboxes {

	static ChromeDriver driver;
	public void check(List<String> list) {

		List<WebElement> lang = driver.findElements(By.xpath("//div[@class='example']/div"));
		for (int i = 0; i < list.size(); i++) {
		for (int j = 0; j < lang.size(); j++) {
				if (lang.get(j).getText().equalsIgnoreCase(list.get(i))) {
					lang.get(j).click();
				//	System.out.println(lang.get(j).getText());
				}
			
			
			}
			}
	
	}
	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/checkbox.html");
		String text = driver.findElement(By.xpath("//div[@class='example']/div/input")).getText();
		System.out.println(text);
		List<String> list = new ArrayList<String>();
		list.add("java");
		list.add("sql");
		Checkboxes ck = new Checkboxes();
		ck.check(list);
		}

}
