package nov24;

import org.testng.annotations.Test;

public class MergeContactTest {
  @Test
  public void f() {
  }
}
