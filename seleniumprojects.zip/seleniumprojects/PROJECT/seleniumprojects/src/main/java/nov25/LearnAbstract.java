package nov25;

public final class LearnAbstract {

	

}
