package nov25;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnDataProvider {

	@Test(dataProvider = "fetchData")
	public void login(String username, String password) {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.className("decorativeSubmit")).click();

	}

	@DataProvider(name = "fetchData")
	public String[][] sendData() {

		String[][] data = new String[2][2];

		data[0][0] = "Demosalesmanager";
		data[0][1] = "crmsfa";

		data[1][0] = "demosalsemanager";
		data[1][1] = "crmsfa";
		
		return data;

	}

}
