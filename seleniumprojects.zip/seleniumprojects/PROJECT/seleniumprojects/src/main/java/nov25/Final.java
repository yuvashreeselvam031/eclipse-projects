package nov25;

public class Final  {

	public static void main(String[] args) {

		LearnAbstract l = new LearnAbstract();
	
	}

}
